let number = 0;
let history = [];
let redoStack = [];

const numberDisplay = document.getElementById('numberDisplay');
const progressBar = document.getElementById('progress');

const updateDisplay = () => {
    numberDisplay.innerText = number;
    const progressPercentage = (number / 150) * 100;
    progressBar.style.width = progressPercentage + '%';
};

const add = () => {
    if (number < 150) {
        history.push(number);
        number++;
        redoStack = [];
        updateDisplay();
    }
};

const subtract = () => {
    if (number > 0) {
        history.push(number);
        number--;
        redoStack = [];
        updateDisplay();
    }
};

const undo = () => {
    if (history.length > 0) {
        redoStack.push(number);
        number = history.pop();
        updateDisplay();
    }
};

const redo = () => {
    if (redoStack.length > 0) {
        history.push(number);
        number = redoStack.pop();
        updateDisplay();
    }
};

document.getElementById('addBtn').addEventListener('click', add);
document.getElementById('subtractBtn').addEventListener('click', subtract);
document.getElementById('undoBtn').addEventListener('click', undo);
document.getElementById('redoBtn').addEventListener('click', redo);
